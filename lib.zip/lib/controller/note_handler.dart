import 'package:lecture_14/controller/dbhelper.dart';
import 'package:lecture_14/linker.dart';


addNote(String title, String message, String time) {
  Note note = Note();

  note.title = title;
  note.message = message;
  note.date = time;
  DBHelper db = DBHelper.instance;
  db.create(note);

  Get.to(HomeView());
}
