import 'package:lecture_14/linker.dart';
import 'package:lecture_14/view/form_view.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text("Notes"),
          actions: [
            IconButton(
                onPressed: () {
                  Get.to(AddNoteView());
                },
                icon: const Icon(Icons.add)),
            IconButton(
                onPressed: () {
                  logout();
                },
                icon: const Icon(Icons.logout))
          ],
        ),
      ),
    );
  }
}
