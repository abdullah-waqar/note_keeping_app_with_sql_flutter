class Note {
  int? id;
  String? title;
  String? message;
  String? date;
}
